import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSupplierSchema, insertClientSchema, insertInvoiceSchema, insertServiceTemplateSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // ===== SUPPLIER =====
  app.get("/api/supplier", (_req, res) => {
    const supplier = storage.getSupplier();
    res.json(supplier || null);
  });

  app.post("/api/supplier", (req, res) => {
    try {
      const parsed = insertSupplierSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.flatten() });
      }
      const supplier = storage.upsertSupplier(parsed.data);
      res.json(supplier);
    } catch (err: any) {
      console.error("Error saving supplier:", err);
      res.status(500).json({ message: err.message || "Internal error" });
    }
  });

  // ===== CLIENTS =====
  app.get("/api/clients", (_req, res) => {
    const clients = storage.getClients();
    res.json(clients);
  });

  app.get("/api/clients/:id", (req, res) => {
    const client = storage.getClient(Number(req.params.id));
    if (!client) return res.status(404).json({ error: "Client not found" });
    res.json(client);
  });

  app.post("/api/clients", (req, res) => {
    const parsed = insertClientSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.flatten() });
    }
    const client = storage.createClient(parsed.data);
    res.json(client);
  });

  app.put("/api/clients/:id", (req, res) => {
    const parsed = insertClientSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.flatten() });
    }
    const client = storage.updateClient(Number(req.params.id), parsed.data);
    if (!client) return res.status(404).json({ error: "Client not found" });
    res.json(client);
  });

  app.delete("/api/clients/:id", (req, res) => {
    storage.deleteClient(Number(req.params.id));
    res.json({ ok: true });
  });

  // ===== INVOICES =====
  app.get("/api/invoices", (_req, res) => {
    const invoiceList = storage.getInvoices();
    res.json(invoiceList);
  });

  app.get("/api/invoices/next-number", (_req, res) => {
    res.json({ number: storage.getNextInvoiceNumber() });
  });

  app.get("/api/invoices/:id", (req, res) => {
    const invoice = storage.getInvoice(Number(req.params.id));
    if (!invoice) return res.status(404).json({ error: "Invoice not found" });
    res.json(invoice);
  });

  app.post("/api/invoices", (req, res) => {
    try {
      const parsed = insertInvoiceSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.flatten() });
      }
      const invoice = storage.createInvoice(parsed.data);
      res.json(invoice);
    } catch (err: any) {
      console.error("Error creating invoice:", err);
      res.status(500).json({ message: err.message || "Internal error" });
    }
  });

  app.put("/api/invoices/:id", (req, res) => {
    try {
      const invoice = storage.updateInvoice(Number(req.params.id), req.body);
      if (!invoice) return res.status(404).json({ error: "Invoice not found" });
      res.json(invoice);
    } catch (err: any) {
      console.error("Error updating invoice:", err);
      res.status(500).json({ message: err.message || "Internal error" });
    }
  });

  app.delete("/api/invoices/:id", (req, res) => {
    storage.deleteInvoice(Number(req.params.id));
    res.json({ ok: true });
  });

  // ===== SERVICE TEMPLATES =====
  app.get("/api/service-templates", (_req, res) => {
    res.json(storage.getServiceTemplates());
  });

  app.post("/api/service-templates", (req, res) => {
    const parsed = insertServiceTemplateSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.flatten() });
    }
    res.json(storage.createServiceTemplate(parsed.data));
  });

  app.delete("/api/service-templates/:id", (req, res) => {
    storage.deleteServiceTemplate(Number(req.params.id));
    res.json({ ok: true });
  });

  // ===== EXCHANGE RATES =====
  let cachedRates: any = null;
  let cacheTime = 0;
  
  app.get("/api/exchange-rates", async (_req, res) => {
    const now = Date.now();
    // Cache for 1 hour
    if (cachedRates && now - cacheTime < 3600000) {
      return res.json(cachedRates);
    }
    try {
      // Try CNB API first
      const cnbRes = await fetch("https://api.cnb.cz/cnbapi/exrates/daily?lang=EN");
      const cnbData = await cnbRes.json();
      const rates: Record<string, number> = { CZK: 1 };
      if (cnbData.rates) {
        for (const r of cnbData.rates) {
          // CNB gives rate as "amount units of currency = rate CZK"
          rates[r.currencyCode] = r.rate / r.amount;
        }
      }
      cachedRates = {
        source: "CNB",
        date: cnbData.date || new Date().toISOString().split("T")[0],
        rates,
        updatedAt: new Date().toISOString(),
      };
      cacheTime = now;
      res.json(cachedRates);
    } catch {
      // Fallback to Frankfurter
      try {
        const ffRes = await fetch("https://api.frankfurter.dev/v1/latest?base=EUR&symbols=CZK,USD,GBP,PLN,CHF");
        const ffData = await ffRes.json();
        const rates: Record<string, number> = { EUR: 1 };
        if (ffData.rates) {
          for (const [code, val] of Object.entries(ffData.rates)) {
            rates[code] = val as number;
          }
        }
        cachedRates = {
          source: "Frankfurter/ECB",
          date: ffData.date || new Date().toISOString().split("T")[0],
          baseIsEUR: true,
          rates,
          updatedAt: new Date().toISOString(),
        };
        cacheTime = now;
        res.json(cachedRates);
      } catch {
        res.status(503).json({ error: "Exchange rates unavailable" });
      }
    }
  });

  // ===== VAT VALIDATION (VIES proxy) =====
  app.get("/api/validate-vat/:vatNumber", async (req, res) => {
    const vatNumber = req.params.vatNumber.replace(/\s/g, "").toUpperCase();
    const countryCode = vatNumber.substring(0, 2);
    const number = vatNumber.substring(2);

    // Basic format check
    const vatRegex = /^[A-Z]{2}[A-Z0-9]{2,12}$/;
    const formatValid = vatRegex.test(vatNumber);

    // Try VIES with timeout
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 8000);
      const response = await fetch(
        `https://ec.europa.eu/taxation_customs/vies/rest-api/check-vat-number`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ countryCode, vatNumber: number }),
          signal: controller.signal,
        }
      );
      clearTimeout(timeout);
      const data = await response.json();
      res.json({
        valid: data.valid || false,
        name: data.name || "",
        address: data.address || "",
        countryCode,
        vatNumber: number,
      });
    } catch {
      // VIES unavailable — return format validation with friendly note
      res.json({
        valid: formatValid,
        name: "",
        address: "",
        countryCode,
        vatNumber: number,
        note: formatValid
          ? "VIES service temporarily unavailable. VAT number format is valid."
          : "VIES service unavailable and VAT number format appears invalid.",
      });
    }
  });

  return httpServer;
}
