import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import { eq, desc } from "drizzle-orm";
import {
  suppliers, clients, invoices, serviceTemplates,
  type Supplier, type InsertSupplier,
  type Client, type InsertClient,
  type Invoice, type InsertInvoice,
  type ServiceTemplate, type InsertServiceTemplate,
} from "@shared/schema";

const sqlite = new Database("database.sqlite");
sqlite.pragma("journal_mode = WAL");
export const db = drizzle(sqlite);

// Auto-create tables if they don't exist
sqlite.exec(`
  CREATE TABLE IF NOT EXISTS suppliers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    address TEXT NOT NULL,
    city TEXT NOT NULL,
    zip TEXT NOT NULL,
    country TEXT NOT NULL DEFAULT 'CZ',
    ico TEXT NOT NULL,
    dic TEXT,
    vat_status TEXT NOT NULL DEFAULT 'neplatce',
    bank_name TEXT,
    iban TEXT,
    swift TEXT,
    email TEXT,
    phone TEXT
  );
  CREATE TABLE IF NOT EXISTS clients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    address TEXT NOT NULL,
    city TEXT NOT NULL,
    zip TEXT NOT NULL,
    country TEXT NOT NULL,
    vat_number TEXT,
    registration_number TEXT,
    email TEXT,
    contact_person TEXT
  );
  CREATE TABLE IF NOT EXISTS invoices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_number TEXT NOT NULL UNIQUE,
    status TEXT NOT NULL DEFAULT 'draft',
    client_id INTEGER NOT NULL,
    supplier_id INTEGER NOT NULL,
    issue_date TEXT NOT NULL,
    delivery_date TEXT NOT NULL,
    due_date TEXT NOT NULL,
    currency TEXT NOT NULL DEFAULT 'EUR',
    exchange_rate REAL DEFAULT 1,
    subtotal REAL NOT NULL DEFAULT 0,
    vat_rate REAL NOT NULL DEFAULT 0,
    vat_amount REAL NOT NULL DEFAULT 0,
    total REAL NOT NULL DEFAULT 0,
    is_reverse_charge INTEGER NOT NULL DEFAULT 0,
    notes TEXT,
    line_items TEXT NOT NULL DEFAULT '[]',
    service_period TEXT,
    signature_block_enabled INTEGER NOT NULL DEFAULT 0,
    acceptance_clause_enabled INTEGER NOT NULL DEFAULT 0,
    secondary_language_enabled INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS service_templates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    description TEXT NOT NULL,
    unit_price REAL NOT NULL,
    unit TEXT NOT NULL DEFAULT 'hrs',
    currency TEXT NOT NULL DEFAULT 'EUR'
  );
`);

// Helper: safely add a column if it doesn't exist
function safeAddColumn(table: string, column: string, definition: string) {
  try {
    const cols = sqlite.prepare(`PRAGMA table_info(${table})`).all() as any[];
    if (!cols.some((c: any) => c.name === column)) {
      sqlite.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
      console.log(`Migration: added ${table}.${column}`);
    }
  } catch (e) {
    console.error(`Migration warning (${table}.${column}):`, e);
  }
}

// Supplier migrations
try {
  const cols = sqlite.prepare("PRAGMA table_info(suppliers)").all() as any[];
  const hasVatStatus = cols.some((c: any) => c.name === "vat_status");
  const hasIsVatPayer = cols.some((c: any) => c.name === "is_vat_payer");
  if (!hasVatStatus) {
    sqlite.exec("ALTER TABLE suppliers ADD COLUMN vat_status TEXT NOT NULL DEFAULT 'neplatce'");
    if (hasIsVatPayer) {
      sqlite.exec("UPDATE suppliers SET vat_status = CASE WHEN is_vat_payer = 1 THEN 'platce' ELSE 'neplatce' END");
    }
  }
} catch (e) { console.error("Migration warning (suppliers):", e); }

// Service templates migrations
safeAddColumn("service_templates", "currency", "TEXT NOT NULL DEFAULT 'EUR'");

// Invoice migrations — each runs independently
safeAddColumn("invoices", "service_period", "TEXT");
safeAddColumn("invoices", "signature_block_enabled", "INTEGER NOT NULL DEFAULT 0");
safeAddColumn("invoices", "acceptance_clause_enabled", "INTEGER NOT NULL DEFAULT 0");
safeAddColumn("invoices", "secondary_language_enabled", "INTEGER NOT NULL DEFAULT 0");

export interface IStorage {
  // Suppliers
  getSupplier(): Supplier | undefined;
  upsertSupplier(data: InsertSupplier): Supplier;

  // Clients
  getClients(): Client[];
  getClient(id: number): Client | undefined;
  createClient(data: InsertClient): Client;
  updateClient(id: number, data: InsertClient): Client | undefined;
  deleteClient(id: number): void;

  // Invoices
  getInvoices(): Invoice[];
  getInvoice(id: number): Invoice | undefined;
  createInvoice(data: InsertInvoice): Invoice;
  updateInvoice(id: number, data: Partial<InsertInvoice>): Invoice | undefined;
  deleteInvoice(id: number): void;
  getNextInvoiceNumber(): string;

  // Service Templates
  getServiceTemplates(): ServiceTemplate[];
  createServiceTemplate(data: InsertServiceTemplate): ServiceTemplate;
  deleteServiceTemplate(id: number): void;
}

export class DatabaseStorage implements IStorage {
  // Suppliers
  getSupplier(): Supplier | undefined {
    return db.select().from(suppliers).get();
  }

  upsertSupplier(data: InsertSupplier): Supplier {
    const existing = this.getSupplier();
    if (existing) {
      return db.update(suppliers).set(data).where(eq(suppliers.id, existing.id)).returning().get()!;
    }
    return db.insert(suppliers).values(data).returning().get()!;
  }

  // Clients
  getClients(): Client[] {
    return db.select().from(clients).all();
  }

  getClient(id: number): Client | undefined {
    return db.select().from(clients).where(eq(clients.id, id)).get();
  }

  createClient(data: InsertClient): Client {
    return db.insert(clients).values(data).returning().get()!;
  }

  updateClient(id: number, data: InsertClient): Client | undefined {
    return db.update(clients).set(data).where(eq(clients.id, id)).returning().get();
  }

  deleteClient(id: number): void {
    db.delete(clients).where(eq(clients.id, id)).run();
  }

  // Invoices
  getInvoices(): Invoice[] {
    return db.select().from(invoices).orderBy(desc(invoices.id)).all();
  }

  getInvoice(id: number): Invoice | undefined {
    return db.select().from(invoices).where(eq(invoices.id, id)).get();
  }

  createInvoice(data: InsertInvoice): Invoice {
    return db.insert(invoices).values(data).returning().get()!;
  }

  updateInvoice(id: number, data: Partial<InsertInvoice>): Invoice | undefined {
    return db.update(invoices).set(data).where(eq(invoices.id, id)).returning().get();
  }

  deleteInvoice(id: number): void {
    db.delete(invoices).where(eq(invoices.id, id)).run();
  }

  getNextInvoiceNumber(): string {
    const year = new Date().getFullYear();
    const allInvoices = db.select().from(invoices).all();
    const thisYearInvoices = allInvoices.filter(inv => inv.invoiceNumber.includes(`${year}`));
    const nextNum = thisYearInvoices.length + 1;
    return `INV-${year}-${String(nextNum).padStart(3, "0")}`;
  }

  // Service Templates
  getServiceTemplates(): ServiceTemplate[] {
    return db.select().from(serviceTemplates).all();
  }

  createServiceTemplate(data: InsertServiceTemplate): ServiceTemplate {
    return db.insert(serviceTemplates).values(data).returning().get()!;
  }

  deleteServiceTemplate(id: number): void {
    db.delete(serviceTemplates).where(eq(serviceTemplates.id, id)).run();
  }
}

export const storage = new DatabaseStorage();
