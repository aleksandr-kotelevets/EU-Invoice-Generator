# Faktura — EU Invoice Generator

A self-hosted invoice generator for Czech OSVČ (sole traders), with EU B2B reverse charge logic, VIES VAT validation, live CNB exchange rates, and bilingual EN/UA support.

---

## Deploy your own copy (Railway — free)

Each person who wants their own instance should follow these steps. **Data is completely separate per deployment.**

### Step 1 — Create a GitHub account
If you don't have one: [github.com/signup](https://github.com/signup)

### Step 2 — Upload this project to GitHub

1. Go to [github.com/new](https://github.com/new)
2. Name it `faktura-invoice` (or anything you like)
3. Set it to **Private**
4. Click **Create repository**
5. On the next page, click **uploading an existing file**
6. Upload the contents of this zip (all files and folders)
7. Click **Commit changes**

### Step 3 — Deploy on Railway

1. Go to [railway.app](https://railway.app) and sign up with your GitHub account (free)
2. Click **New Project → Deploy from GitHub repo**
3. Select your `faktura-invoice` repository
4. Railway will automatically detect Node.js and run `npm run build`
5. After ~2 minutes, click **Settings → Networking → Generate Domain**
6. You get a free URL like `faktura-invoice-production.up.railway.app`

That's it. Your own private invoice app, completely separate from anyone else's.

---

## What's included

- Invoice creation with all EU Directive 2006/112/EC required fields
- Three VAT regimes: **neplátce DPH**, **identifikovaná osoba** (§6i), **plátce DPH**
- Automatic reverse charge for EU B2B with correct legal texts
- Souhrnné hlášení reminder on dashboard
- VIES VAT number validation
- Live exchange rates from Czech National Bank (ČNB)
- Multi-currency dashboard (EUR / CZK / USD)
- Service templates (preset services)
- PDF export via Print
- Bilingual invoices (EN + UA)
- Signature block and acceptance clause toggles
- Dark / light theme
- Three UI languages: English, Czech, Ukrainian

---

## Local development

```bash
npm install
npm run dev
```

App runs at http://localhost:5000

## Tech stack

- **Frontend:** React + Vite + Tailwind CSS + shadcn/ui
- **Backend:** Express.js + SQLite (better-sqlite3) + Drizzle ORM
- **Data:** Stored locally in `database.sqlite`
