import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Supplier settings (your OSVČ data)
export const suppliers = sqliteTable("suppliers", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  zip: text("zip").notNull(),
  country: text("country").notNull().default("CZ"),
  ico: text("ico").notNull(),
  dic: text("dic"), // DIČ — always shown for identifikovaná osoba
  vatStatus: text("vat_status").notNull().default("neplatce"), // neplatce | identifikovana | platce
  bankName: text("bank_name"),
  iban: text("iban"),
  swift: text("swift"),
  email: text("email"),
  phone: text("phone"),
});

export const insertSupplierSchema = createInsertSchema(suppliers).omit({ id: true });
export type InsertSupplier = z.infer<typeof insertSupplierSchema>;
export type Supplier = typeof suppliers.$inferSelect;

export type VatStatus = "neplatce" | "identifikovana" | "platce";

// Clients
export const clients = sqliteTable("clients", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  zip: text("zip").notNull(),
  country: text("country").notNull(),
  vatNumber: text("vat_number"),
  registrationNumber: text("registration_number"),
  email: text("email"),
  contactPerson: text("contact_person"),
});

export const insertClientSchema = createInsertSchema(clients).omit({ id: true });
export type InsertClient = z.infer<typeof insertClientSchema>;
export type Client = typeof clients.$inferSelect;

// Invoices
export const invoices = sqliteTable("invoices", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  invoiceNumber: text("invoice_number").notNull().unique(),
  status: text("status").notNull().default("draft"),
  clientId: integer("client_id").notNull(),
  supplierId: integer("supplier_id").notNull(),
  issueDate: text("issue_date").notNull(),
  deliveryDate: text("delivery_date").notNull(),
  dueDate: text("due_date").notNull(),
  currency: text("currency").notNull().default("EUR"),
  exchangeRate: real("exchange_rate").default(1),
  subtotal: real("subtotal").notNull().default(0),
  vatRate: real("vat_rate").notNull().default(0),
  vatAmount: real("vat_amount").notNull().default(0),
  total: real("total").notNull().default(0),
  isReverseCharge: integer("is_reverse_charge", { mode: "boolean" }).notNull().default(false),
  notes: text("notes"),
  lineItems: text("line_items").notNull().default("[]"),
  servicePeriod: text("service_period"),
  signatureBlockEnabled: integer("signature_block_enabled", { mode: "boolean" }).notNull().default(false),
  acceptanceClauseEnabled: integer("acceptance_clause_enabled", { mode: "boolean" }).notNull().default(false),
  secondaryLanguageEnabled: integer("secondary_language_enabled", { mode: "boolean" }).notNull().default(false),
  createdAt: text("created_at").notNull(),
});

export const insertInvoiceSchema = createInsertSchema(invoices).omit({ id: true });
export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;
export type Invoice = typeof invoices.$inferSelect;

// Service templates (presets)
export const serviceTemplates = sqliteTable("service_templates", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  description: text("description").notNull(),
  unitPrice: real("unit_price").notNull(),
  unit: text("unit").notNull().default("hrs"),
  currency: text("currency").notNull().default("EUR"),
});

export const insertServiceTemplateSchema = createInsertSchema(serviceTemplates).omit({ id: true });
export type InsertServiceTemplate = z.infer<typeof insertServiceTemplateSchema>;
export type ServiceTemplate = typeof serviceTemplates.$inferSelect;

// Line item type (stored as JSON in invoices)
export const lineItemSchema = z.object({
  description: z.string().min(1),
  quantity: z.number().min(0.01),
  unit: z.string().min(1),
  unitPrice: z.number().min(0),
  total: z.number(),
});

export type LineItem = z.infer<typeof lineItemSchema>;

// EU country list
export const EU_COUNTRIES = [
  { code: "AT", name: "Austria" },
  { code: "BE", name: "Belgium" },
  { code: "BG", name: "Bulgaria" },
  { code: "HR", name: "Croatia" },
  { code: "CY", name: "Cyprus" },
  { code: "CZ", name: "Czech Republic" },
  { code: "DK", name: "Denmark" },
  { code: "EE", name: "Estonia" },
  { code: "FI", name: "Finland" },
  { code: "FR", name: "France" },
  { code: "DE", name: "Germany" },
  { code: "GR", name: "Greece" },
  { code: "HU", name: "Hungary" },
  { code: "IE", name: "Ireland" },
  { code: "IT", name: "Italy" },
  { code: "LV", name: "Latvia" },
  { code: "LT", name: "Lithuania" },
  { code: "LU", name: "Luxembourg" },
  { code: "MT", name: "Malta" },
  { code: "NL", name: "Netherlands" },
  { code: "PL", name: "Poland" },
  { code: "PT", name: "Portugal" },
  { code: "RO", name: "Romania" },
  { code: "SK", name: "Slovakia" },
  { code: "SI", name: "Slovenia" },
  { code: "ES", name: "Spain" },
  { code: "SE", name: "Sweden" },
] as const;

export const CURRENCIES = ["EUR", "CZK", "USD", "GBP", "PLN", "CHF"] as const;
